package org.example.rawabet.controllers;

import lombok.RequiredArgsConstructor;
import org.example.rawabet.dto.AuthResponse;
import org.example.rawabet.dto.LoginRequest;
import org.example.rawabet.dto.ResetPasswordOtpRequest;
import org.example.rawabet.dto.ResetPasswordRequest;
import org.example.rawabet.services.AuthServiceImpl;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.time.Duration;

@RestController
@RequestMapping("/auth")
@Validated
public class AuthController {

    private static final String RESET_COOKIE_NAME = "rawabet_reset_token";

    private final AuthServiceImpl authService;

    @Value("${app.frontend.url}")
    private String frontendUrl;

    @Value("${app.cookie.secure:false}")
    private boolean secureCookie;

    public AuthController(AuthServiceImpl authService) {
        this.authService = authService;
    }

    @PostMapping("/login")
    public AuthResponse login(@RequestBody LoginRequest request) {
        return authService.login(request);
    }
    @PostMapping("/test")
    public String test() {
        return "OK";
    }

    @PostMapping("/logout")
    public String logout() {
        // côté client → supprimer le token du localStorage/cookie
        return "Logged out successfully";
    }
    // =========================
// 🔐 FORGOT PASSWORD
// =========================
    @PostMapping("/forgot-password")
    public String forgotPassword(@RequestParam String email) {
        authService.forgotPassword(email);
        return "✅ Si cet email existe, un code OTP a été envoyé.";
    }

    @GetMapping("/reset-password/confirm")
    public ResponseEntity<Void> confirmResetPasswordToken(@RequestParam String token) {
        authService.validateResetToken(token);

        ResponseCookie cookie = ResponseCookie.from(RESET_COOKIE_NAME, token)
                .httpOnly(true)
                .secure(secureCookie)
                .sameSite("Strict")
                .path("/")
                .maxAge(Duration.ofMinutes(15))
                .build();

        return ResponseEntity.status(302)
                .header(HttpHeaders.SET_COOKIE, cookie.toString())
                .location(URI.create(frontendUrl + "/auth/reset-password"))
                .build();
    }

    // =========================
// 🔐 RESET PASSWORD
// =========================
    @PostMapping("/reset-password/session")
    public String resetPasswordWithSession(
            @CookieValue(name = RESET_COOKIE_NAME, required = false) String token,
            @RequestBody @jakarta.validation.Valid ResetPasswordRequest request,
            HttpServletResponse response) {

        if (token == null || token.isBlank()) {
            throw new RuntimeException("Session de réinitialisation invalide ou expirée");
        }

        authService.resetPassword(token, request.getNewPassword());

        ResponseCookie clearCookie = ResponseCookie.from(RESET_COOKIE_NAME, "")
                .httpOnly(true)
                .secure(secureCookie)
                .sameSite("Strict")
                .path("/")
                .maxAge(0)
                .build();

        response.addHeader(HttpHeaders.SET_COOKIE, clearCookie.toString());
        return "✅ Mot de passe réinitialisé avec succès !";
    }

    @PostMapping("/reset-password")
    public String resetPassword(@RequestParam String token,
                                @RequestParam String newPassword) {
        authService.resetPassword(token, newPassword);
        return "✅ Mot de passe réinitialisé avec succès !";
    }

    @PostMapping("/reset-password/otp")
    public String resetPasswordWithOtp(@RequestBody @jakarta.validation.Valid ResetPasswordOtpRequest request) {
        authService.resetPasswordWithOtp(request.getEmail(), request.getCode(), request.getNewPassword());
        return "✅ Mot de passe réinitialisé avec succès !";
    }
    // =========================
// ✅ VERIFY EMAIL
// =========================
    @GetMapping("/verify-email")
    public String verifyEmail(@RequestParam String token) {
        authService.verifyEmail(token);
        return "✅ Email vérifié avec succès — vous pouvez maintenant vous connecter !";
    }
}