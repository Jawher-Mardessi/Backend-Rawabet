package org.example.rawabet.controllers;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.example.rawabet.dto.RegisterRequest;
import org.example.rawabet.dto.UpdateUserRolesRequest;
import org.example.rawabet.dto.UserResponse;
import org.example.rawabet.services.IUserService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.example.rawabet.dto.UpdateProfileRequest;
import org.example.rawabet.dto.ChangePasswordRequest;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/users")
@RequiredArgsConstructor
public class UserController {

    private final IUserService userService;

    // =========================
    // 👤 REGISTER (CLIENT)
    // =========================
    @PostMapping("/add")
    public UserResponse register(@Valid @RequestBody RegisterRequest request) {
        return userService.register(request);
    }

    // =========================
    // 🔐 CREATE USER (ADMIN)
    // =========================
    @PostMapping("/add-with-role")
    @PreAuthorize("hasAuthority('ADMIN_MANAGE')")
    public UserResponse createUserByAdmin(@Valid @RequestBody RegisterRequest request) {
        return userService.createUserByAdmin(request);
    }

    // =========================
    // ✏️ UPDATE USER
    // CORRECTION — id dans le path au lieu de @RequestParam
    // =========================
    @PutMapping("/update/{id}")
    @PreAuthorize("hasAuthority('ADMIN_MANAGE')")
    public UserResponse updateUser(@PathVariable Long id,
                                   @Valid @RequestBody RegisterRequest request) {
        return userService.updateUser(id, request);
    }

    // =========================
    // 🔐 UPDATE USER ROLES (ADMIN)
    // =========================
    @PutMapping("/{id}/roles")
    @PreAuthorize("hasAuthority('ADMIN_MANAGE')")
    public UserResponse updateUserRoles(@PathVariable Long id,
                                        @Valid @RequestBody UpdateUserRolesRequest request) {
        return userService.updateUserRoles(id, request);
    }

    // =========================
    // ❌ DELETE USER
    // =========================
    @DeleteMapping("/delete/{id}")
    @PreAuthorize("hasAuthority('ADMIN_MANAGE')")
    public void deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
    }

    // =========================
    // 🔍 GET USER BY ID
    // =========================
    @GetMapping("/get/{id}")
    @PreAuthorize("hasAuthority('ADMIN_MANAGE')")
    public UserResponse getUserById(@PathVariable Long id) {
        return userService.getUserById(id);
    }

    // =========================
    // 📋 GET ALL USERS — paginé
    // CORRECTION — Page<UserResponse> au lieu de List<UserResponse>
    // Ex: GET /users/all?page=0&size=20&sort=createdAt&direction=desc
    // =========================
    @GetMapping("/all")
    @PreAuthorize("hasAuthority('ADMIN_MANAGE')")
    public Page<UserResponse> getAllUsers(
            @RequestParam(defaultValue = "0")        int page,
            @RequestParam(defaultValue = "20")       int size,
            @RequestParam(defaultValue = "createdAt") String sort,
            @RequestParam(defaultValue = "desc")     String direction) {

        Sort sortObj = direction.equalsIgnoreCase("asc")
                ? Sort.by(sort).ascending()
                : Sort.by(sort).descending();

        return userService.getAllUsers(PageRequest.of(page, size, sortObj));
    }

    // =========================
    // 👤 GET MY PROFILE
    // =========================
    @GetMapping("/me")
    public UserResponse getMyProfile() {
        return userService.getMyProfile();
    }

    // =========================
    // ✏️ UPDATE MY PROFILE
    // =========================
    @PutMapping("/me/update")
    public UserResponse updateMyProfile(@Valid @RequestBody UpdateProfileRequest request) {
        return userService.updateMyProfile(request);
    }

    @PostMapping(value = "/me/avatar", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public UserResponse uploadMyAvatar(@RequestPart("file") MultipartFile file) {
        return userService.uploadMyAvatar(file);
    }

    // =========================
    // 🔐 CHANGE PASSWORD
    // =========================
    @PutMapping("/me/password")
    public String changeMyPassword(@Valid @RequestBody ChangePasswordRequest request) {
        userService.changeMyPassword(request);
        return "✅ Mot de passe modifié avec succès";
    }

    // =========================
    // 🚫 BAN USER
    // =========================
    @PutMapping("/{id}/ban")
    @PreAuthorize("hasAuthority('ADMIN_MANAGE')")
    public String banUser(@PathVariable Long id) {
        userService.banUser(id);
        return "✅ User " + id + " banni avec succès";
    }

    // =========================
    // ✅ UNBAN USER
    // =========================
    @PutMapping("/{id}/unban")
    @PreAuthorize("hasAuthority('ADMIN_MANAGE')")
    public String unbanUser(@PathVariable Long id) {
        userService.unbanUser(id);
        return "✅ User " + id + " réactivé avec succès";
    }
}