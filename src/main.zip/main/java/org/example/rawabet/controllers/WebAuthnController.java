package org.example.rawabet.controllers;

import lombok.RequiredArgsConstructor;
import org.example.rawabet.dto.AuthResponse;
import org.example.rawabet.dto.webauthn.PasskeyFinishAuthenticationRequest;
import org.example.rawabet.dto.webauthn.PasskeyFinishRegistrationRequest;
import org.example.rawabet.dto.webauthn.PasskeyStartAuthenticationRequest;
import org.example.rawabet.dto.webauthn.PasskeyStartAuthenticationResponse;
import org.example.rawabet.dto.webauthn.PasskeyStartRegistrationRequest;
import org.example.rawabet.dto.webauthn.PasskeyStartRegistrationResponse;
import org.example.rawabet.services.PasskeyService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth/webauthn")
@RequiredArgsConstructor
public class WebAuthnController {

    private final PasskeyService passkeyService;

    @PostMapping("/registration/start")
    public PasskeyStartRegistrationResponse startRegistration(@RequestBody PasskeyStartRegistrationRequest request) {
        return passkeyService.startRegistration(request);
    }

    @PostMapping("/registration/finish")
    public void finishRegistration(@RequestBody PasskeyFinishRegistrationRequest request) {
        passkeyService.finishRegistration(request);
    }

    @PostMapping("/authentication/start")
    public PasskeyStartAuthenticationResponse startAuthentication(@RequestBody(required = false) PasskeyStartAuthenticationRequest request) {
        return passkeyService.startAuthentication(request);
    }

    @PostMapping("/authentication/finish")
    public AuthResponse finishAuthentication(@RequestBody PasskeyFinishAuthenticationRequest request) {
        return passkeyService.finishAuthentication(request);
    }
}