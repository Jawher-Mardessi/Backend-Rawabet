package org.example.rawabet.entities;

import jakarta.persistence.*;
import lombok.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Getter @Setter @AllArgsConstructor @NoArgsConstructor
public class User {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nom;

    @Column(unique = true)
    private String email;

    private String avatarUrl;

    @JsonIgnore
    private String password;

    @Column(name = "token_version", nullable = false)
    private int tokenVersion = 0;

    @Column(nullable = false, columnDefinition = "boolean default true")
    private boolean isActive = true;

    // AJOUT — audit temporel, gérés automatiquement par Hibernate
    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "user_roles",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "role_id")
    )
    private List<Role> roles;

    @OneToMany(mappedBy = "user")
    @JsonIgnore
    private List<ReservationCinema> reservationCinemas;

    @OneToMany(mappedBy = "user")
    @JsonIgnore
    private List<ReservationEvenement> reservationEvenements;

    @OneToMany(mappedBy = "user")
    @JsonIgnore
    private List<Notification> notifications;

    @OneToMany(mappedBy = "user")
    @JsonIgnore
    private List<Feedback> feedbacks;

    @OneToOne(mappedBy = "user")
    @JsonIgnore
    private CarteFidelite carteFidelite;

    @OneToOne(mappedBy = "user")
    private Abonnement abonnement;

    // SUPPRIMÉ — tous les getters/setters manuels
    // @Getter et @Setter Lombok les génèrent déjà, les doublons créaient un risque de divergence
}