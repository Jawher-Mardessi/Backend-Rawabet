package org.example.rawabet.enums;

public enum NotificationType {
    EMAIL,
    SMS,
    PUSH
}
