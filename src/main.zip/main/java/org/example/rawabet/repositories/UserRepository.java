package org.example.rawabet.repositories;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.example.rawabet.entities.User;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByEmail(String email);

    Optional<User> findByEmailIgnoreCase(String email);

    /**
     * Recherche par nom ou email (utilisateurs actifs uniquement).
     */
    @Query("""
        SELECT u FROM User u
        WHERE u.isActive = true
          AND (LOWER(u.nom)   LIKE LOWER(CONCAT('%', :query, '%'))
               OR LOWER(u.email) LIKE LOWER(CONCAT('%', :query, '%')))
    """)
    List<User> searchByNomOrEmail(@Param("query") String query);

    /**
     * Correction N+1 : charge tous les users avec leur CarteFidelite
     * en une seule requête JOIN (au lieu de N requêtes dans mapToResponse).
     *
     * Utilisé par getAllUsers() côté admin.
     */
    @Query("""
        SELECT DISTINCT u FROM User u
        LEFT JOIN FETCH u.carteFidelite
        LEFT JOIN FETCH u.roles
    """)
    List<User> findAllWithCarteAndRoles();

    /**
     * Version paginée pour getAllUsers() — remplace findAll() sans Pageable.
     */
    Page<User> findAll(Pageable pageable);
}