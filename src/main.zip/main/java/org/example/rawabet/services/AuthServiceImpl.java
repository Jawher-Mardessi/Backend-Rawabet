package org.example.rawabet.services;

import lombok.RequiredArgsConstructor;
import org.example.rawabet.dto.AuthResponse;
import org.example.rawabet.dto.LoginRequest;
import org.example.rawabet.entities.EmailVerificationToken;
import org.example.rawabet.entities.PasswordResetToken;
import org.example.rawabet.entities.User;
import org.example.rawabet.repositories.EmailVerificationTokenRepository;
import org.example.rawabet.repositories.PasswordResetTokenRepository;
import org.example.rawabet.repositories.UserRepository;
import org.example.rawabet.security.JwtService;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements IAuthService {

    private static final int OTP_LENGTH = 6;
    private static final int MAX_OTP_ATTEMPTS = 5;

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final PasswordResetTokenRepository resetTokenRepository;
    private final EmailService emailService;
    private final EmailVerificationTokenRepository verificationTokenRepository;

    // 🔐 LOGIN
    @Override
    public AuthResponse login(LoginRequest request) {

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("User not found"));

        // ✅ vérifier si banni
        if (!user.isActive()) {
            throw new RuntimeException("Compte désactivé — contactez l'administrateur");
        }

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid credentials");
        }

        String token = jwtService.generateToken(user);
        return new AuthResponse(token);
    }

    // 🔐 LOGOUT
    @Override
    public void logout() {
        // stateless JWT — rien côté serveur
    }

    // 🔐 GET AUTHENTICATED USER
    @Override
    public User getAuthenticatedUser() {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null || !authentication.isAuthenticated()) {
            throw new RuntimeException("User not authenticated");
        }

        Object principal = authentication.getPrincipal();

        if (!(principal instanceof User)) {
            throw new RuntimeException("Invalid authentication principal");
        }

        return (User) principal;
    }

    // =========================
// 🔐 FORGOT PASSWORD
// =========================
    @Override
    @Transactional
    public void forgotPassword(String email) {

        User user = userRepository.findByEmail(email).orElse(null);
        if (user == null) {
            // Réponse neutre anti-énumération d'emails
            return;
        }

        // ✅ générer OTP 6 chiffres
        String otpCode = generateOtpCode();
        String otpHash = hashToken(otpCode);

        // ✅ réutiliser le token existant du user (évite conflit unique sur user_id)
        PasswordResetToken resetToken = resetTokenRepository.findByUser(user)
            .orElseGet(PasswordResetToken::new);
        resetToken.setToken(otpHash);
        resetToken.setUser(user);
        resetToken.setExpiresAt(LocalDateTime.now().plusMinutes(15));
        resetToken.setUsed(false);
        resetToken.setFailedAttempts(0);

        resetTokenRepository.save(resetToken);

        // ✅ envoyer email
        emailService.sendPasswordResetOtpEmail(email, otpCode);
    }

    @Override
    @Transactional(readOnly = true)
    public void validateResetToken(String token) {
        String tokenHash = hashToken(token);

        PasswordResetToken resetToken = resetTokenRepository.findByToken(tokenHash)
                .orElseThrow(() -> new RuntimeException("Token invalide"));

        if (resetToken.isExpired()) {
            throw new RuntimeException("Token expiré — demandez un nouveau lien");
        }

        if (resetToken.isUsed()) {
            throw new RuntimeException("Token déjà utilisé");
        }
    }

    // =========================
// 🔐 RESET PASSWORD
// =========================
    @Override
    @Transactional
    public void resetPassword(String token, String newPassword) {

        String tokenHash = hashToken(token);

        PasswordResetToken resetToken = resetTokenRepository.findByToken(tokenHash)
                .orElseThrow(() -> new RuntimeException("Token invalide"));

        // ✅ vérifier expiration
        if (resetToken.isExpired()) {
            throw new RuntimeException("Token expiré — demandez un nouveau lien");
        }

        // ✅ vérifier déjà utilisé
        if (resetToken.isUsed()) {
            throw new RuntimeException("Token déjà utilisé");
        }

        // ✅ changer mot de passe
        User user = resetToken.getUser();
        user.setPassword(passwordEncoder.encode(newPassword));
        user.setTokenVersion(user.getTokenVersion() + 1);
        userRepository.save(user);

        // ✅ marquer token comme utilisé
        resetToken.setUsed(true);
        resetTokenRepository.save(resetToken);
    }

    @Override
    @Transactional
    public void resetPasswordWithOtp(String email, String code, String newPassword) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Code invalide ou expiré"));

        PasswordResetToken resetToken = resetTokenRepository.findByUser(user)
                .orElseThrow(() -> new RuntimeException("Code invalide ou expiré"));

        if (resetToken.isExpired()) {
            throw new RuntimeException("Code expiré — demandez un nouveau code");
        }

        if (resetToken.isUsed()) {
            throw new RuntimeException("Code déjà utilisé");
        }

        if (resetToken.getFailedAttempts() >= MAX_OTP_ATTEMPTS) {
            throw new RuntimeException("Trop de tentatives — demandez un nouveau code");
        }

        String providedCodeHash = hashToken(code);
        if (!providedCodeHash.equals(resetToken.getToken())) {
            resetToken.setFailedAttempts(resetToken.getFailedAttempts() + 1);
            resetTokenRepository.save(resetToken);
            throw new RuntimeException("Code invalide ou expiré");
        }

        user.setPassword(passwordEncoder.encode(newPassword));
        user.setTokenVersion(user.getTokenVersion() + 1);
        userRepository.save(user);

        resetToken.setUsed(true);
        resetTokenRepository.save(resetToken);
    }

    // =========================
// ✅ VERIFY EMAIL
// =========================
    @Override
    @Transactional
    public void verifyEmail(String token) {

        EmailVerificationToken verificationToken = verificationTokenRepository.findByToken(token)
                .orElseThrow(() -> new RuntimeException("Token invalide"));

        // ✅ vérifier expiration
        if (verificationToken.isExpired()) {
            throw new RuntimeException("Token expiré — demandez un nouveau lien");
        }

        // ✅ activer le compte
        User user = verificationToken.getUser();
        user.setActive(true);
        userRepository.save(user);

        // ✅ supprimer le token
        verificationTokenRepository.delete(verificationToken);
    }

    private String hashToken(String token) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashed = digest.digest(token.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hashed) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("Hash algorithm unavailable", e);
        }
    }

    private String generateOtpCode() {
        SecureRandom secureRandom = new SecureRandom();
        int value = secureRandom.nextInt(1_000_000);
        return String.format("%0" + OTP_LENGTH + "d", value);
    }
}