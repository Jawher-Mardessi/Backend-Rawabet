package org.example.rawabet.services;

import org.example.rawabet.dto.ChangePasswordRequest;
import org.example.rawabet.dto.RegisterRequest;
import org.example.rawabet.dto.UpdateProfileRequest;
import org.example.rawabet.dto.UpdateUserRolesRequest;
import org.example.rawabet.dto.UserResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.multipart.MultipartFile;

public interface IUserService {

    // 👤 inscription simple (CLIENT)
    UserResponse register(RegisterRequest request);

    // 🔐 ADMIN crée user avec rôle
    UserResponse createUserByAdmin(RegisterRequest request);

    UserResponse updateUser(Long id, RegisterRequest request);

    void deleteUser(Long id);

    UserResponse getUserById(Long id);

    // CORRECTION — paginé au lieu de List<UserResponse>
    Page<UserResponse> getAllUsers(Pageable pageable);

    // 👤 profil connecté
    UserResponse getMyProfile();
    UserResponse updateMyProfile(UpdateProfileRequest request);
    UserResponse uploadMyAvatar(MultipartFile file);
    void changeMyPassword(ChangePasswordRequest request);
    UserResponse updateUserRoles(Long id, UpdateUserRolesRequest request);
    void banUser(Long id);
    void unbanUser(Long id);
}