package org.example.rawabet.services;

import lombok.RequiredArgsConstructor;
import org.example.rawabet.dto.ChangePasswordRequest;
import org.example.rawabet.dto.RegisterRequest;
import org.example.rawabet.dto.UpdateProfileRequest;
import org.example.rawabet.dto.UpdateUserRolesRequest;
import org.example.rawabet.dto.UserResponse;
import org.example.rawabet.entities.CarteFidelite;
import org.example.rawabet.entities.EmailVerificationToken;
import org.example.rawabet.entities.Role;
import org.example.rawabet.entities.User;
import org.example.rawabet.enums.Level;
import org.example.rawabet.repositories.CarteFideliteRepository;
import org.example.rawabet.repositories.EmailVerificationTokenRepository;
import org.example.rawabet.repositories.RoleRepository;
import org.example.rawabet.repositories.UserRepository;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements IUserService {

    private static final long MAX_AVATAR_SIZE = 5L * 1024 * 1024;

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;
    private final CarteFideliteRepository carteRepository;
    private final IAuthService authService;
    private final EmailVerificationTokenRepository verificationTokenRepository;
    private final EmailService emailService;

    // =========================
    // 👤 REGISTER (CLIENT)
    // =========================
    @Override
    @Transactional
    public UserResponse register(RegisterRequest request) {
        checkEmail(request.getEmail());

        Role clientRole = roleRepository.findByName("CLIENT")
                .orElseThrow(() -> new RuntimeException("CLIENT role not found"));

        User user = new User();
        user.setNom(request.getNom());
        user.setEmail(request.getEmail().toLowerCase().trim());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRoles(List.of(clientRole));
        user.setActive(true); // 🧪 TEST — remettre false + sendVerificationEmail en prod

        try {
            User savedUser = userRepository.save(user);
            carteRepository.save(createCarte(savedUser));
            // sendVerificationEmail(savedUser); // 🧪 TEST — décommenter en prod
            return mapToResponse(savedUser);
        } catch (DataIntegrityViolationException e) {
            throw new RuntimeException("Email already exists");
        }
    }

    // =========================
    // 🔐 CREATE USER (ADMIN)
    // =========================
    @Override
    @Transactional
    public UserResponse createUserByAdmin(RegisterRequest request) {
        checkEmail(request.getEmail());

        if (request.getRoles() == null || request.getRoles().isEmpty()) {
            throw new RuntimeException("Roles are required");
        }

        List<String> roleNames = request.getRoles()
                .stream()
                .map(String::toUpperCase)
                .toList();

        if (roleNames.contains("SUPER_ADMIN")) {
            throw new RuntimeException("Cannot assign SUPER_ADMIN role");
        }

        List<Role> roles = roleRepository.findByNameIn(roleNames);
        if (roles.size() != roleNames.size()) {
            throw new RuntimeException("Some roles are invalid");
        }

        User user = new User();
        user.setNom(request.getNom());
        user.setEmail(request.getEmail().toLowerCase().trim());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRoles(roles);
        user.setActive(true);

        try {
            User savedUser = userRepository.save(user);
            carteRepository.save(createCarte(savedUser));
            return mapToResponse(savedUser);
        } catch (DataIntegrityViolationException e) {
            throw new RuntimeException("Email already exists");
        }
    }

    // =========================
    // ✏️ UPDATE USER
    // =========================
    @Override
    @Transactional
    public UserResponse updateUser(Long id, RegisterRequest request) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));

        user.setNom(request.getNom());

        if (!Objects.equals(user.getEmail(), request.getEmail())) {
            checkEmail(request.getEmail());
            user.setEmail(request.getEmail().toLowerCase().trim());
        }

        if (request.getPassword() != null) {
            if (request.getPassword().isBlank()) {
                throw new RuntimeException("Le mot de passe ne peut pas être vide");
            }
            user.setPassword(passwordEncoder.encode(request.getPassword()));
            user.setTokenVersion(user.getTokenVersion() + 1);
        }

        try {
            return mapToResponse(userRepository.save(user));
        } catch (DataIntegrityViolationException e) {
            throw new RuntimeException("Email already exists");
        }
    }

    // =========================
    // ❌ DELETE USER
    // =========================
    @Override
    @Transactional
    public void deleteUser(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));

        carteRepository.findByUser(user)
                .ifPresent(carteRepository::delete);

        userRepository.delete(user);
    }

    // =========================
    // 🔍 GET USER BY ID
    // =========================
    @Override
    public UserResponse getUserById(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return mapToResponse(user);
    }

    // =========================
    // 📋 GET ALL USERS — paginé
    // =========================
    @Override
    public Page<UserResponse> getAllUsers(Pageable pageable) {
        return userRepository.findAll(pageable)
                .map(this::mapToResponse);
    }

    // =========================
    // 👤 GET MY PROFILE
    // =========================
    @Override
    public UserResponse getMyProfile() {
        User user = authService.getAuthenticatedUser();
        return mapToResponse(user);
    }

    // =========================
    // ✏️ UPDATE MY PROFILE
    // =========================
    @Override
    @Transactional
    public UserResponse updateMyProfile(UpdateProfileRequest request) {
        User user = authService.getAuthenticatedUser();

        user.setNom(request.getNom());

        if (!Objects.equals(user.getEmail(), request.getEmail())) {
            checkEmail(request.getEmail());
            user.setEmail(request.getEmail().toLowerCase().trim());
        }

        try {
            return mapToResponse(userRepository.save(user));
        } catch (DataIntegrityViolationException e) {
            throw new RuntimeException("Email already exists");
        }
    }

    // =========================
    // 🖼️ UPLOAD AVATAR
    // =========================
    @Override
    @Transactional
    public UserResponse uploadMyAvatar(MultipartFile file) {
        User user = authService.getAuthenticatedUser();

        if (file == null || file.isEmpty()) {
            throw new RuntimeException("Aucun fichier image fourni");
        }

        String contentType = file.getContentType();
        if (contentType == null || !contentType.startsWith("image/")) {
            throw new RuntimeException("Format invalide — envoyez une image");
        }

        if (file.getSize() > MAX_AVATAR_SIZE) {
            throw new RuntimeException("Image trop volumineuse (max 5MB)");
        }

        validateImageMagicBytes(file);

        String extension = resolveExtension(file.getOriginalFilename(), contentType);
        String filename = "avatar-" + user.getId() + "-" + UUID.randomUUID() + extension;
        Path avatarDir = Paths.get("uploads", "avatars").toAbsolutePath().normalize();
        Path target = avatarDir.resolve(filename);

        try {
            Files.createDirectories(avatarDir);
            Files.copy(file.getInputStream(), target, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            throw new RuntimeException("Impossible d'enregistrer l'image", e);
        }

        String oldAvatarUrl = user.getAvatarUrl();
        user.setAvatarUrl("/uploads/avatars/" + filename);
        UserResponse response = mapToResponse(userRepository.save(user));
        deleteOldAvatarFile(oldAvatarUrl);

        return response;
    }

    // =========================
    // 🔐 CHANGE MY PASSWORD
    // =========================
    @Override
    @Transactional
    public void changeMyPassword(ChangePasswordRequest request) {
        User user = authService.getAuthenticatedUser();

        if (!passwordEncoder.matches(request.getOldPassword(), user.getPassword())) {
            throw new RuntimeException("Ancien mot de passe incorrect");
        }

        if (passwordEncoder.matches(request.getNewPassword(), user.getPassword())) {
            throw new RuntimeException("Le nouveau mot de passe doit être différent");
        }

        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        user.setTokenVersion(user.getTokenVersion() + 1);
        userRepository.save(user);
    }

    // =========================
    // 🔐 UPDATE USER ROLES (ADMIN)
    // =========================
    @Override
    @Transactional
    public UserResponse updateUserRoles(Long id, UpdateUserRolesRequest request) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));

        boolean targetIsSuperAdmin = user.getRoles().stream()
                .anyMatch(r -> "SUPER_ADMIN".equals(r.getName()));
        if (targetIsSuperAdmin) {
            throw new RuntimeException("Impossible de modifier les roles d'un SUPER_ADMIN");
        }

        List<String> requestedRoleNames = request.getRoles().stream()
                .map(String::toUpperCase)
                .distinct()
                .toList();

        if (requestedRoleNames.contains("SUPER_ADMIN")) {
            throw new RuntimeException("Cannot assign SUPER_ADMIN role");
        }

        List<Role> roles = roleRepository.findByNameIn(requestedRoleNames);
        if (roles.size() != requestedRoleNames.size()) {
            throw new RuntimeException("Some roles are invalid");
        }

        user.setRoles(roles);
        user.setTokenVersion(user.getTokenVersion() + 1);
        return mapToResponse(userRepository.save(user));
    }

    // =========================
    // 🚫 BAN USER
    // =========================
    @Override
    @Transactional
    public void banUser(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!user.isActive()) {
            throw new RuntimeException("User déjà banni");
        }

        boolean isSuperAdmin = user.getRoles().stream()
                .anyMatch(r -> r.getName().equals("SUPER_ADMIN"));
        if (isSuperAdmin) {
            throw new RuntimeException("Impossible de bannir un SUPER_ADMIN");
        }

        user.setActive(false);
        user.setTokenVersion(user.getTokenVersion() + 1);
        userRepository.save(user);
    }

    // =========================
    // ✅ UNBAN USER
    // =========================
    @Override
    @Transactional
    public void unbanUser(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (user.isActive()) {
            throw new RuntimeException("User déjà actif");
        }

        user.setActive(true);
        user.setTokenVersion(user.getTokenVersion() + 1);
        userRepository.save(user);
    }

    // =========================
    // 🔐 EMAIL CHECK
    // =========================
    private void checkEmail(String email) {
        if (userRepository.findByEmail(email.toLowerCase().trim()).isPresent()) {
            throw new RuntimeException("Email already exists");
        }
    }

    // =========================
    // 💳 CREATE CARTE
    // =========================
    private CarteFidelite createCarte(User user) {
        return CarteFidelite.builder()
                .user(user)
                .points(0)
                .level(Level.SILVER)
                .dateExpiration(LocalDate.now().plusYears(1))
                .build();
    }

    // =========================
    // 🔥 MAPPING
    // =========================
    private UserResponse mapToResponse(User user) {
        CarteFidelite carte = carteRepository.findByUser(user).orElse(null);

        return UserResponse.builder()
                .id(user.getId())
                .nom(user.getNom())
                .email(user.getEmail())
                .avatarUrl(user.getAvatarUrl())
                .roles(user.getRoles().stream()
                        .map(Role::getName)
                        .toList())
                .isActive(user.isActive())
                .loyaltyLevel(carte != null ? carte.getLevel().name() : "SILVER")
                .loyaltyPoints(carte != null ? carte.getPoints() : 0)
                .build();
    }

    private String resolveExtension(String originalFilename, String contentType) {
        if (originalFilename != null && originalFilename.contains(".")) {
            String ext = originalFilename.substring(originalFilename.lastIndexOf('.')).toLowerCase();
            if (ext.matches("\\.(png|jpg|jpeg|webp|gif)")) {
                return ext;
            }
        }

        if ("image/png".equalsIgnoreCase(contentType))  return ".png";
        if ("image/jpeg".equalsIgnoreCase(contentType)) return ".jpg";
        if ("image/webp".equalsIgnoreCase(contentType)) return ".webp";
        if ("image/gif".equalsIgnoreCase(contentType))  return ".gif";
        return ".img";
    }

    private void deleteOldAvatarFile(String avatarUrl) {
        if (avatarUrl == null || !avatarUrl.startsWith("/uploads/avatars/")) {
            return;
        }
        String oldFilename = avatarUrl.substring("/uploads/avatars/".length());
        Path oldFile = Paths.get("uploads", "avatars", oldFilename).toAbsolutePath().normalize();
        try {
            Files.deleteIfExists(oldFile);
        } catch (IOException ignored) {
            // Non bloquant — la sauvegarde DB est déjà réussie
        }
    }

    // =========================
    // 🔍 MAGIC BYTES VALIDATION
    // =========================
    private void validateImageMagicBytes(MultipartFile file) {
        try {
            byte[] header = file.getInputStream().readNBytes(12);
            if (!isPng(header) && !isJpeg(header) && !isGif(header) && !isWebp(header)) {
                throw new RuntimeException("Contenu du fichier invalide — image PNG, JPEG, WEBP ou GIF requise");
            }
        } catch (IOException e) {
            throw new RuntimeException("Impossible de lire le fichier");
        }
    }

    private boolean isPng(byte[] h) {
        return h.length >= 4
                && h[0] == (byte) 0x89 && h[1] == 0x50
                && h[2] == 0x4E && h[3] == 0x47;
    }

    private boolean isJpeg(byte[] h) {
        return h.length >= 3
                && h[0] == (byte) 0xFF && h[1] == (byte) 0xD8 && h[2] == (byte) 0xFF;
    }

    private boolean isGif(byte[] h) {
        return h.length >= 4
                && h[0] == 0x47 && h[1] == 0x49 && h[2] == 0x46 && h[3] == 0x38;
    }

    private boolean isWebp(byte[] h) {
        return h.length >= 12
                && h[0] == 0x52 && h[1] == 0x49 && h[2] == 0x46 && h[3] == 0x46
                && h[8] == 0x57 && h[9] == 0x45 && h[10] == 0x42 && h[11] == 0x50;
    }

    // =========================
    // 📧 SEND VERIFICATION EMAIL
    // =========================
    private void sendVerificationEmail(User user) {
        verificationTokenRepository.deleteByUser(user);

        String token = UUID.randomUUID().toString();

        EmailVerificationToken verificationToken = new EmailVerificationToken();
        verificationToken.setToken(token);
        verificationToken.setUser(user);
        verificationToken.setExpiresAt(LocalDateTime.now().plusHours(24));
        verificationTokenRepository.save(verificationToken);

        emailService.sendVerificationEmail(user.getEmail(), token);
    }
}